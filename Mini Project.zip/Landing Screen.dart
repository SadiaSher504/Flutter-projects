import 'package:flutter/material.dart';

class LandingScreen extends StatelessWidget {
  const LandingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
      Container(
        alignment: Alignment.center,
        color: Colors.white,
        child: Column(
         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
                Container(
                    child: Column(
                      children: [
                        Container(
                          child: Text(
                            'Shopsie',
                            style: TextStyle(color:Color(0xff626BFC),fontSize: 60,
                              fontWeight: FontWeight.bold,
                            )
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.all(10),
                          child: Text(
                            'The best way to style your life',
                            style: TextStyle(color: Colors.grey.shade700,fontSize: 12,),
                          ),
                        ),
                      ],
                    ),
                ),
            Container(
              //alignment: Alignment.bottomCenter,
                  child: MaterialButton(
                    minWidth: 350,
                    height: 50,
                    shape: OutlineInputBorder(borderRadius: BorderRadius.circular(50),borderSide: BorderSide.none),
                    onPressed:(){
                    },
                    child:Text('Get Started',style: TextStyle(fontSize:20 ,fontWeight: FontWeight.w600),),
                    color:Color(0xff626BFC),
                    textColor: Colors.white,
                  ),
                ),
             ],
            ),
        ),
    );
  }
}


