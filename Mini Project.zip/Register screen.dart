import 'package:flutter/material.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  TextEditingController textEditingController=TextEditingController();
  TextEditingController textEditingController1=TextEditingController();
  TextEditingController textEditingController2=TextEditingController();
  TextEditingController textEditingController3=TextEditingController();
  String Fname=" ",Lname=" ", Email=" ",Password=" ";
  @override
  Widget build(BuildContext context) {
    return Scaffold( body:Container(
      color: Colors.white,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Text(
                    'Hello! Register to get started',
                    style: TextStyle(color: Colors.black,fontSize: 25,fontWeight: FontWeight.bold,),
                  ),

                ),
              ),
            ],
          ),

          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              controller:textEditingController,
              decoration: InputDecoration(
                  fillColor: Colors.blue,
                  border: OutlineInputBorder(borderSide: BorderSide(width: 2),borderRadius: BorderRadius.circular(10)),
                  hintText:'First Name',hintStyle: TextStyle(fontWeight:FontWeight.w500,color: Colors.grey ),),

            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              controller:textEditingController1,
              decoration: InputDecoration(
                  fillColor: Colors.blue,
                  border: OutlineInputBorder(borderSide: BorderSide(width: 2),borderRadius: BorderRadius.circular(10)),
                  hintText:'Last Name',hintStyle: TextStyle(fontWeight:FontWeight.w500,color: Colors.grey )),
            ),
          ),Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              controller:textEditingController2,
              decoration: InputDecoration(
                  fillColor: Colors.blue,
                  border: OutlineInputBorder(borderSide: BorderSide(width: 2),borderRadius: BorderRadius.circular(10)),
                  hintText:'Email',hintStyle: TextStyle(fontWeight:FontWeight.w500,color: Colors.grey )),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              controller:textEditingController,
              decoration: InputDecoration(
                fillColor: Colors.blue,
                border: OutlineInputBorder(borderSide: BorderSide(width: 2),borderRadius: BorderRadius.circular(10)),
                hintText:'Password',hintStyle: TextStyle(fontWeight:FontWeight.w500,color: Colors.grey )
                ,),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: MaterialButton(
              minWidth: double.infinity,
              height: 50,
              shape: OutlineInputBorder(borderRadius: BorderRadius.circular(10),borderSide: BorderSide.none),
              onPressed:(){
                Fname='${textEditingController.text}';
                Lname='${textEditingController1.text}';
                Email='${textEditingController2.text}';
                Password='${textEditingController3.text}';
                setState(() {

                });
              },
              child:Text('Register',),
              color:Color(0xff626BFC),
              textColor: Colors.white,
            ),
          ),

          SizedBox(height: 0.06,),
          SingleChildScrollView(
            child: Container(
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 0,vertical: 20,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 1,
                      width: 150,
                      color: Colors.black45,
                    ),
                    Text(
                      '   or Login with   ',
                      style: TextStyle(color: Colors.black45,fontSize: 15,fontWeight: FontWeight.normal,),
                    ),
                    Container(
                      height: 1,
                      width: 150,
                      color: Colors.black45,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 50,
                      vertical:3,
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: Colors.black45),
                      //color: Colors.white,
                    ),
                    child: Image.asset("images/facebook.webp"),
                    height: 50,
                    width: 200,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 50,
                      vertical:2,
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: Colors.black45),
                      // color: Colors.white,
                    ),
                    child: Image.asset("images/googleicon.png"),
                    height: 50,
                    width: 200,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Dont have an account? ',
                  style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.normal,),
                ),
                Text(
                  'Register Now',
                  style: TextStyle(color:Color(0xff626BFC),fontSize: 15,fontWeight: FontWeight.normal,),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
    );
  }
}
