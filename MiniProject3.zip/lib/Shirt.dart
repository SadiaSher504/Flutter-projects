import 'package:flutter/material.dart';

class Shirt extends StatelessWidget {
  const Shirt({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Shirts',
          style: TextStyle(
            fontSize: 25,
            color: Color(0xff626BFC),
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: GridView(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 0.58,
          ),
          children: <Widget>[
            Column(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    child: Image.asset(
                      'assets/images/SH11.webp',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Textured Lawn Kurti-Embroided(Pret)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold,),textDirection: TextDirection.ltr,
                ),
                SizedBox(height: 5),
                Text(
                  '\$90.0',
                  style: TextStyle(fontSize: 16, color: Color(0xff626BFC),fontWeight: FontWeight.bold)
                  ,textDirection: TextDirection.ltr,
                ),
              ],
            ),
            Column(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    child: Image.asset(
                      'assets/images/Sh2.webp',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Relax Fit Embroidered Button Down Shirt',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)
                  ,textDirection: TextDirection.ltr,
                ),
                SizedBox(height: 5),
                Text(
                  '\$100.0',
                  style: TextStyle(fontSize: 16, color: Color(0xff626BFC),fontWeight: FontWeight.bold)
                  ,textDirection: TextDirection.ltr,
                ),
              ],
            ),
            Column(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    child: Image.asset(
                      'assets/images/SH3.webp',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Lawn Embroided shirt',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
                SizedBox(height: 5),
                Text(
                  '\$80.0',
                  style: TextStyle(fontSize: 16, color: Color(0xff626BFC),fontWeight: FontWeight.bold),

                    textDirection: TextDirection.ltr),
              ],
            ),
            Column(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    child: Image.asset(
                      'assets/images/SH4.webp',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Lawn Paste Print',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
                SizedBox(height: 5),
                Text(
                  '\$50.0',
                  style: TextStyle(fontSize: 16, color: Color(0xff626BFC),fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
              ],
            ),
            Column(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    child: Image.asset(
                      'assets/images/SH5.webp',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Textured Shirt With Turn Up Sleeves',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
                SizedBox(height: 5),
                Text(
                  '\$70.0',
                  style: TextStyle(fontSize: 16, color: Color(0xff626BFC),fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
              ],
            ),
            Column(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    child: Image.asset(
                      'assets/images/SH6.webp',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Lawn Kurti Printed',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
                SizedBox(height: 5),
                Text(
                  '\$90.0',
                  style: TextStyle(fontSize: 16, color: Color(0xff626BFC),fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
              ],
            ),
            Column(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    child: Image.asset(
                      'assets/images/SH7.webp',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Jaquard Kurti-Embroided',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
                SizedBox(height: 5),
                Text(
                  '\$100.0',
                  style: TextStyle(fontSize: 16, color: Color(0xff626BFC),fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
              ],
            ),
            Column(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    child: Image.asset(
                      'assets/images/SH8.webp',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Lawn Kurti-Embroided(Pret)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
                SizedBox(height: 5),
                Text(
                  '\$80.0',
                  style: TextStyle(fontSize: 16, color: Color(0xff626BFC),fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
              ],
            ),
            Column(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    child: Image.asset(
                      'assets/images/SH9.webp',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Curduroy Kurti-Dyed(Pret)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
                SizedBox(height: 5),
                Text(
                  '\$290.0',
                  style: TextStyle(fontSize: 16, color: Color(0xff626BFC),fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
              ],
            ),
            Column(
              children: [
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    child: Image.asset(
                      'assets/images/SH10.webp',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  'Jaquard Kurti-Embroided',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
                SizedBox(height: 5),
                Text(
                  '\$95.0',
                  style: TextStyle(fontSize: 16, color: Color(0xff626BFC),fontWeight: FontWeight.bold),
                    textDirection: TextDirection.ltr
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
