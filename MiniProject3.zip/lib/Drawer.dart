import 'package:flutter/material.dart';
import 'package:miniproject_3/RegisterScreen.dart';
import 'LoginScreen.dart';
import 'MainScreen.dart';

class Menudrawer extends StatelessWidget {
  const Menudrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.white,
      child: ListView(
        children: buildMenuItems(context),
      ),
    );
  }

  List<Widget> buildMenuItems(BuildContext context) {
    List<Widget> menuItems = [];

    menuItems.add(
      Container(
        child: DrawerHeader(
         child: CircleAvatar(
           radius: 150,
           backgroundImage: AssetImage('assets/images/Profile1.jpg'),
         ),
        ),
      ),
    );

    menuItems.add(
      Text(
        'Information',
        style: TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
    );

    menuItems.add(
      ListTile(
        title: Text(
          'Edit Profile',
          style: TextStyle(color: Colors.black),
        ),
        leading: Icon(Icons.edit_calendar_sharp),
      ),
    );

    menuItems.add(
      ListTile(
        title: Text(
          'Username',
          style: TextStyle(color: Colors.black),
        ),
        leading: Icon(Icons.person),
      ),
    );

    menuItems.add(
      ListTile(
        title: Text(
          'E-mail',
          style: TextStyle(color: Colors.black),
        ),
        leading: Icon(Icons.email_outlined),
      ),
    );

    menuItems.add(
      ListTile(
        title: Text(
          'Password',
          style: TextStyle(color: Colors.black),
        ),
        leading: Icon(Icons.lock_rounded),
      ),
    );

    menuItems.add(
      Container(
        height: 1,
        width: 120,
        color: Colors.black45,
      ),
    );

    menuItems.add(
      Text(
        'Categories',
        style: TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
    );

    menuItems.add(
      ListTile(
        title: Text(
          'All Categories',
          style: TextStyle(color: Colors.black),
        ),
        leading: Icon(Icons.category_outlined),
      ),
    );

    menuItems.add(
      ListTile(
        title: Text(
          'Shirts',
          style: TextStyle(color: Colors.black),
        ),
        leading: Icon(Icons.confirmation_num_sharp),
      ),
    );

    menuItems.add(
      ListTile(
        title: Text(
          'Bottoms',
          style: TextStyle(color: Colors.black),
        ),
        leading: Icon(Icons.email_outlined),
      ),
    );

    menuItems.add(
      ListTile(
        title: Text(
          'Shoes',
          style: TextStyle(color: Colors.black),
        ),
        leading: Icon(Icons.lock_rounded),
      ),
    );

    menuItems.add(
      ListTile(
        title: Text(
          'Heels',
          style: TextStyle(color: Colors.black),
        ),
        leading: Icon(Icons.lock_rounded),
      ),
    );

    menuItems.add(
      ListTile(
        title: Text(
          'Accessories',
          style: TextStyle(color: Colors.black),
        ),
        leading: Icon(Icons.lock_rounded),
      ),
    );

    menuItems.add(
      ListTile(
        title: Text(
          'Tops',
          style: TextStyle(color: Colors.black),
        ),
        leading: Icon(Icons.lock_rounded),
      ),
    );

    return menuItems;
  }
}
