import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:miniproject_3/Drawer1.dart';

import 'Drawer.dart';
class MainScreen extends StatelessWidget{
  TextEditingController textEditingController=TextEditingController();
  String mail=" ";
  MainScreen(this.mail);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(toolbarHeight: 100,backgroundColor: Colors.white,
        title: Text('Shopsie',style: TextStyle(color: Color(0xff626BFC),fontWeight: FontWeight.bold),),
        centerTitle: true,
        actions: <Widget>[
          IconButton(onPressed:(){}, icon:const Icon(Icons.search)),
          IconButton(onPressed:(){}, icon:const Icon(Icons.shopping_cart_outlined)),
          IconButton(onPressed:(){}, icon:const Icon(Icons.account_circle)),
        ],
        //leading: IconButton(onPressed: (){},icon:const Icon(Icons.menu) ,),
      ),
      drawer: Drawer1(),
      body:
      Container(
        //margin: EdgeInsets.all(20),
        color: Colors.white,
        child: ListView(
          children: [
            Container(
              height: 500,
              color: Colors.white,
              //margin: EdgeInsets.all(10),
              child: Image.asset(
                'assets/images/mainbanner.jpg',
                fit: BoxFit.fill,),
            ),
            Container(
              margin: EdgeInsets.all(10),
              alignment: Alignment.center,
              child: ElevatedButton(
                onPressed:(){},
                child: Text('Shop Now',style: TextStyle(color: Colors.black),) ,
                style:ElevatedButton.styleFrom(shape: OvalBorder(side: BorderSide(width: 1)),fixedSize: Size(150, 50),backgroundColor: Colors.grey.shade300),
              ),
            ),
            Container(
              height: 300,
              color: Colors.grey,
              margin: EdgeInsets.all(10),
              child: Image.asset(
                'assets/images/banner2.jpg',fit: BoxFit.fill,
              ),
            ),
            Container(
                alignment: Alignment.center,
                height: 50,
                color: Colors.white,
                //  margin: EdgeInsets.all(10),
                child: Text('TRENDING NOW',style: TextStyle(color: Colors.black,fontSize: 25),
                  textAlign:TextAlign.center ,
                )
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Container(
                    margin: EdgeInsets.all(3),
                    child: ElevatedButton(
                      onPressed:(){},
                      child: Text('All',style: TextStyle(color: Colors.white,fontSize: 15),) ,
                      style:ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                        backgroundColor: Color(0xff626BFC),),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.all(3),
                    child: ElevatedButton(
                      onPressed:(){},
                      child: Text('Dresses',style: TextStyle(color: Colors.black,fontSize: 15,),) ,
                      style:ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                          backgroundColor: Colors.grey.shade200),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.all(3),
                    child: ElevatedButton(
                      onPressed:(){},
                      child: Text('Accessories',style: TextStyle(color: Colors.black,fontSize: 15),) ,
                      style:ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                          backgroundColor: Colors.grey.shade200),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.all(3),
                    child: ElevatedButton(
                        onPressed:(){},
                        child: Text('Jewellary',style: TextStyle(color: Colors.black,fontSize: 15),) ,
                        style:ElevatedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                          backgroundColor: Colors.grey.shade200,)
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.symmetric(vertical: 20.0),
              height: 400.0,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children:[
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(width: 200.0, child: Image.asset('assets/images/heels.jpg',fit: BoxFit.fill,),),
                      ),
                      Container(child: Text('Printed Dress',style: TextStyle(color: Colors.black),))
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(width: 200.0, child: Image.asset('assets/images/2p.webp',fit: BoxFit.fill,),),
                      ),
                      Container(child: Text('Printed Dress',style: TextStyle(color: Colors.black),))
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(width: 200.0, child: Image.asset('assets/images/3p.jpg'),),
                      ),
                      Container(child: Text('Printed Dress',style: TextStyle(color: Colors.black),))
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(width: 200.0, child: Image.asset('assets/images/4p.jpg'),),
                      ),
                      Container(child: Text('Printed Dress',style: TextStyle(color: Colors.black),))
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(width: 200.0, child: Image.asset('assets/images/5p.jpg'),),
                      ),
                      Container(child: Text('Printed Dress',style: TextStyle(color: Colors.black),))
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(width: 200.0, child: Image.asset('assets/images/6p.jpg'),),
                      ),
                      Container(child: Text('Printed Dress',style: TextStyle(color: Colors.black),))
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(width: 200.0, child: Image.asset('assets/images/2p.webp'),),
                      ),
                      Container(child: Text('Printed Dress',style: TextStyle(color: Colors.black),))
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(width: 200.0, child: Image.asset('assets/images/3p.jpg'),),
                      ),
                      Container(child: Text('Printed Dress',style: TextStyle(color: Colors.black),))
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(width: 200.0, child: Image.asset('assets/images/4p.jpg'),),
                      ),
                      Container(child: Text('Printed Dress',style: TextStyle(color: Colors.black),))
                    ],
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(width: 200.0, child: Image.asset('assets/images/5p.jpg'),),
                      ),
                      Container(child: Text('Printed Dress',style: TextStyle(color: Colors.black),))
                    ],
                  ),
                ],
              ),
            ),
            Container(
                alignment: Alignment.center,
                height: 50,
                color: Colors.white,
                //  margin: EdgeInsets.all(10),
                child: Text('ACTUAL CATEGORIES',style: TextStyle(color: Colors.black,fontSize: 25),
                  textAlign:TextAlign.center ,
                )
            ),
            Container(
              height: 500,
              color: Colors.grey,
              margin: EdgeInsets.all(10),
              child: Image.asset(
                'assets/images/outerwear.webp',fit: BoxFit.fill,
              ),
            ),
            Container(
                alignment: Alignment.center,
                height: 50,
                color: Colors.white,
                //  margin: EdgeInsets.all(10),
                child: Text('Outerwear',style: TextStyle(color: Colors.black,fontSize: 25),
                  textAlign:TextAlign.center ,
                )
            ),
            Container(
                alignment: Alignment.center,
                height: 20,
                color: Colors.white,
                //  margin: EdgeInsets.all(10),
                child: Text('Raincoat,sweaters, etc',style: TextStyle(color: Colors.black45,fontSize: 15),
                  textAlign:TextAlign.center ,
                )
            ),
            Container(
              alignment: Alignment.center,
              height: 500,
              width:600,
              margin: EdgeInsets.all(10),
              child: Image.asset(
                'assets/images/heelpic.jpg',fit: BoxFit.fill,
              ),
            ),
            Container(
                alignment: Alignment.center,
                height: 50,
                color: Colors.white,
                //  margin: EdgeInsets.all(10),
                child: Text('Leather Shoes',style: TextStyle(color: Colors.black,fontSize: 25),
                  textAlign:TextAlign.center ,
                )
            ),
            Container(
                alignment: Alignment.center,
                height: 20,
                color: Colors.white,
                //  margin: EdgeInsets.all(10),
                child: Text('Shoes,sandal, etc',style: TextStyle(color: Colors.black45,fontSize: 15),
                  textAlign:TextAlign.center ,
                )
            ),
            Container(
              height: 500,
              color: Colors.grey,
              margin: EdgeInsets.all(10),
              child: Image.asset(
                'assets/images/lightdress.jpg',fit: BoxFit.fill,
              ),
            ),
            Container(
                alignment: Alignment.center,
                height: 50,
                color: Colors.white,
                //  margin: EdgeInsets.all(10),
                child: Text('Light dresses',style: TextStyle(color: Colors.black,fontSize: 25),
                  textAlign:TextAlign.center ,
                )
            ),
            Container(
                alignment: Alignment.center,
                height: 20,
                color: Colors.white,
                //  margin: EdgeInsets.all(10),
                child: Text('Evenings,casual,home',style: TextStyle(color: Colors.black45,fontSize: 15),
                  textAlign:TextAlign.center ,
                )
            ),
            Padding(
              padding: const EdgeInsets.all(30.0),
              child: Column(
                children: [
                  Container(
                      alignment: Alignment.center,
                      height: 50,
                      color: Colors.white,
                      //  margin: EdgeInsets.all(10),
                      child: Text('Only trusted brands',style: TextStyle(color: Colors.black,fontSize: 25),
                        textAlign:TextAlign.center ,
                      )
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 70,
                        width: 60,
                        margin: EdgeInsets.all(10),
                        child: Image.asset(
                          'assets/images/tiffany.jpg',fit: BoxFit.fill,
                        ),
                      ),Container(
                        height: 70,
                        width: 60,
                        margin: EdgeInsets.all(10),
                        child: Image.asset(
                          'assets/images/D&G.jpg',fit: BoxFit.fill,
                        ),
                      ),Container(
                        height: 70,
                        width: 60,
                        margin: EdgeInsets.all(10),
                        child: Image.asset(
                          'assets/images/rolex1.png',fit: BoxFit.fill,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        height: 70,
                        width: 60,
                        margin: EdgeInsets.all(10),
                        child: Image.asset(
                          'assets/images/gucci.png',fit: BoxFit.fill,
                        ),
                      ),Container(
                        height: 70,
                        width: 60,
                        margin: EdgeInsets.all(10),
                        child: Image.asset(
                          'assets/images/fendi.jpg',fit: BoxFit.fill,
                        ),
                      ),Container(
                        height: 70,
                        width: 60,
                        margin: EdgeInsets.all(10),
                        child: Image.asset(
                          'assets/images/prada.jpg',fit: BoxFit.fill,
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
            Container(
              color: Colors.black,
              child: Column(
                children: [
                  Container(
                      alignment: Alignment.center,
                      height: 80,
                      child: Text('NEW ARRIVAL',style: TextStyle(color: Colors.orangeAccent.shade100,fontSize: 50,),
                        textAlign:TextAlign.center,
                      )
                  ),
                  Container(
                      alignment: Alignment.center,
                      height: 40,
                      child: Text('FALL 2024',style: TextStyle(color: Colors.orangeAccent.shade100,fontSize: 20,),
                        textAlign:TextAlign.center,

                      )
                  ),
                  Container(
                    height: 400,
                    margin: EdgeInsets.all(10),
                    padding: EdgeInsets.all(20),
                    child: Image.asset(
                      'assets/images/newarrival.webp',fit: BoxFit.fill,
                    ),
                  ),
                  Container(
                    alignment: Alignment.center,
                    margin: EdgeInsets.all(10),
                    child: MaterialButton(
                      minWidth: 180,
                      height: 50,
                      shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                      onPressed:(){
                      },
                      child:Text('Explore',style: TextStyle(fontSize:20),),
                      color:Colors.white,
                      textColor: Color(0xff626BFC),
                    ),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                Container(
                    alignment: Alignment.center,
                    height: 80,
                    child: Text('RECOMMENDED LOOKS FOR YOU',style: TextStyle(color: Colors.black,fontSize: 25,),
                      textAlign:TextAlign.center,

                    )
                ),
                Container(
                  height: 500,
                  margin: EdgeInsets.all(10),
                  //padding: EdgeInsets.all(20),
                  child: Image.asset(
                    'assets/images/looks.jpg',fit: BoxFit.fill,
                  ),
                ),
                Container(
                    margin: EdgeInsets.all(20),
                    alignment: Alignment.topLeft,
                    height: 80,
                    child: Text('In This look',style: TextStyle(color: Colors.black,fontSize: 25,),
                      textAlign:TextAlign.center,
                    )
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Container(
                        width: 100,
                        child:ClipRRect(
                          borderRadius: BorderRadius.circular(150),
                          child: Image.asset(
                            'assets/images/looks.jpg',
                          ),
                        ),

                      ),
                      Container(
                          padding: EdgeInsets.all(10),
                          height: 100,
                          child: Text('Cotton black dress',style: TextStyle(color: Colors.black,fontSize: 20,),
                            textAlign:TextAlign.center,
                          )
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Container(
                        width: 100,
                        child:ClipRRect(
                          borderRadius: BorderRadius.circular(150),
                          child: Image.asset(
                            'assets/images/pic1.jpg',
                          ),
                        ),

                      ),
                      Container(
                          padding: EdgeInsets.all(10),
                          height: 100,
                          child: Text('Coat',style: TextStyle(color: Colors.black,fontSize: 25,),
                            textAlign:TextAlign.center,
                          )
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    children: [
                      Container(
                        width: 100,
                        child:ClipRRect(
                          borderRadius: BorderRadius.circular(150),
                          child: Image.asset(
                            'assets/images/heelpic.jpg',
                          ),
                        ),
                      ),
                      Container(
                          height: 100,
                          padding: EdgeInsets.all(10),
                          child: Text('Sandal',style: TextStyle(color: Colors.black,fontSize: 25,),
                            textAlign:TextAlign.center,
                          )
                      ),
                    ],
                  ),
                ),
                Container(
                  alignment: Alignment.center,
                  margin: EdgeInsets.all(10),
                  child: MaterialButton(
                    minWidth: 400,
                    height: 50,
                    shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(4),side: BorderSide(color:Color(0xff626BFC))),
                    onPressed:(){
                    },
                    child:Text('Buy it Now',style: TextStyle(fontSize:20),),
                    color:Colors.white,
                    textColor: Color(0xff626BFC),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    children: [
                      Container(
                        color: Colors.deepPurple.shade100,
                        child: Padding(
                          padding: const EdgeInsets.all(0.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 500,
                                height:300,
                                margin: EdgeInsets.all(50),
                                child: Image.asset(
                                  'assets/images/lastpic.png',fit: BoxFit.fill,
                                ),
                              ),
                              Container(
                                  alignment: Alignment.center,
                                  height: 40,
                                  child: Text('GET 20% OFF',style: TextStyle(color: Colors.black,fontSize: 25,),
                                    textAlign:TextAlign.center,
                                  )
                              ),
                              Container(
                                alignment: Alignment.center,
                                height: 30,
                                child: Text('Leave your email and get discount',style: TextStyle(color: Colors.black45,fontSize: 15,),
                                  textAlign:TextAlign.center,
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(20.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      alignment: Alignment.centerLeft,
                                      padding: EdgeInsets.only(left:5.0,top:0.0,right:0.0,bottom:0.0),
                                      color: Colors.white,
                                      width: 180,
                                      height: 40,
                                      child:Text('${mail}',
                                        style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,fontSize: 15,),textAlign: TextAlign.start,),
                                    ),
                                    Container(
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.all(10),
                                      child: MaterialButton(
                                        minWidth: 90,
                                        height: 45,
                                        shape:RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                                        onPressed:(){
                                        },
                                        child:Text('Subscribe',style: TextStyle(fontSize:20),),
                                        color:Color(0xff626BFC),
                                        textColor: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

              ],
            ),
            Container(
              color: Colors.black,
              height: 50,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    padding: EdgeInsets.all(10 ),
                    child:Text('2024 Shopsie',style: TextStyle(color: Colors.grey),),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        padding: EdgeInsets.all(10 ),
                        child:Text('Privacy and Cookies',style: TextStyle(color: Colors.white),),
                      ),
                      Container(
                        padding: EdgeInsets.all(10 ),
                        child:Text('TS&CS',style: TextStyle(color: Colors.white),),
                      ),
                    ]

                    ,
                  ),

                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
