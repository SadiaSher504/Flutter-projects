import 'package:flutter/material.dart';

import 'MainScreen.dart';
import 'RegisterScreen.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController textEditingController=TextEditingController();
  TextEditingController textEditingController1=TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(' '),backgroundColor: Colors.white,),
      body:SingleChildScrollView(
        child: Container(
          color: Colors.white,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    height: 120,
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Text(
                        'Welcome Back! Glad to   \n''see you,Again!',
                        style: TextStyle(color: Colors.black,fontSize: 25,fontWeight: FontWeight.bold,),
                      ),
        
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: TextField(
                  controller:textEditingController,
                  decoration: InputDecoration(
                    fillColor: Colors.blue,suffixIcon: Icon(Icons.email),
                    border: OutlineInputBorder(borderSide: BorderSide(width: 2),borderRadius: BorderRadius.circular(10)),
                    hintText:'Enter your email',hintStyle: TextStyle(fontWeight:FontWeight.w500,color: Colors.grey )
                    ,),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: TextField(
                  controller:textEditingController1,
                  decoration: InputDecoration(
                      fillColor: Colors.blue,suffixIcon: Icon(Icons.visibility_outlined),
                      border: OutlineInputBorder(borderSide: BorderSide(width: 2),borderRadius: BorderRadius.circular(10)),
                      hintText:'Enter your password',hintStyle: TextStyle(fontWeight:FontWeight.w500,color: Colors.grey )),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: MaterialButton(
                  minWidth: double.infinity,
                  height: 50,
                  shape: OutlineInputBorder(borderRadius: BorderRadius.circular(10),borderSide: BorderSide.none),
                  onPressed:(){
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>MainScreen(textEditingController.text)));
                  },
                  child:Text('Login',),
                  color:Color(0xff626BFC),
                  textColor: Colors.white,
        
                ),
              ),
        
              SizedBox(height: 0.06,),
              SingleChildScrollView(
                child: Container(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 0,vertical: 20,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          height: 1,
                          width: 120,
                          color: Colors.black45,
                        ),
                        Text(
                          '   or Login with   ',
                          style: TextStyle(color: Colors.black45,fontSize: 15,fontWeight: FontWeight.normal,),
                        ),
                        Container(
                          height: 1,
                          width: 120,
                          color: Colors.black45,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 50,
                          vertical:3,
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(color: Colors.black45),
                          //color: Colors.white,
                        ),
                        child: Image.asset("assets/images/facebook.webp"),
                        height: 50,
                        width: 130,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 50,
                          vertical:2,
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          border: Border.all(color: Colors.black45),
                          // color: Colors.white,
                        ),
                        child: Image.asset("assets/images/googleicon.png"),
                        height: 50,
                        width: 130,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Dont have an account? ',
                      style: TextStyle(color: Colors.black,fontSize: 15,fontWeight: FontWeight.normal,),
                    ),
                    ElevatedButton(onPressed: ()
                    {
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>RegisterScreen()));
                    },
                        child:
                        Text(
                          'Register Now',
                          style: TextStyle(color:Color(0xff626BFC),fontSize: 15,fontWeight: FontWeight.normal,),
                        ),
                        style:ElevatedButton.styleFrom(backgroundColor: Colors.white )
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
